/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_312(unsigned *p)
{
    *p = 2488809008U;
}

unsigned getval_149()
{
    return 1483203220U;
}

unsigned addval_481(unsigned x)
{
    return x + 1477624283U;
}

unsigned addval_385(unsigned x)
{
    return x + 1791201400U;
}

void setval_173(unsigned *p)
{
    *p = 3284633928U;
}

unsigned addval_458(unsigned x)
{
    return x + 3284633928U;
}

unsigned getval_400()
{
    return 3284634056U;
}

unsigned addval_186(unsigned x)
{
    return x + 3347671068U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_151(unsigned *p)
{
    *p = 2462747059U;
}

void setval_428(unsigned *p)
{
    *p = 3682915977U;
}

void setval_260(unsigned *p)
{
    *p = 3526940299U;
}

unsigned addval_357(unsigned x)
{
    return x + 3351349648U;
}

unsigned addval_373(unsigned x)
{
    return x + 3534015113U;
}

void setval_286(unsigned *p)
{
    *p = 3281311369U;
}

void setval_336(unsigned *p)
{
    *p = 3281111689U;
}

unsigned getval_462()
{
    return 3676357001U;
}

unsigned getval_128()
{
    return 3286272344U;
}

void setval_218(unsigned *p)
{
    *p = 3281046157U;
}

unsigned getval_421()
{
    return 2464188744U;
}

unsigned addval_104(unsigned x)
{
    return x + 3286272328U;
}

unsigned getval_339()
{
    return 3372272265U;
}

void setval_204(unsigned *p)
{
    *p = 3374896777U;
}

unsigned getval_141()
{
    return 3677405577U;
}

void setval_351(unsigned *p)
{
    *p = 3767093375U;
}

unsigned addval_123(unsigned x)
{
    return x + 3225998985U;
}

void setval_175(unsigned *p)
{
    *p = 3397989135U;
}

unsigned addval_140(unsigned x)
{
    return x + 3682912937U;
}

unsigned getval_360()
{
    return 3286276424U;
}

unsigned getval_441()
{
    return 2495711623U;
}

unsigned getval_396()
{
    return 2378350985U;
}

unsigned addval_108(unsigned x)
{
    return x + 3281049225U;
}

unsigned addval_158(unsigned x)
{
    return x + 3599606464U;
}

unsigned getval_116()
{
    return 3375942281U;
}

unsigned getval_281()
{
    return 1153679755U;
}

unsigned addval_240(unsigned x)
{
    return x + 3285625186U;
}

unsigned addval_341(unsigned x)
{
    return x + 2428602731U;
}

unsigned getval_293()
{
    return 3286272320U;
}

unsigned addval_324(unsigned x)
{
    return x + 3286272329U;
}

unsigned getval_422()
{
    return 3286270280U;
}

unsigned getval_330()
{
    return 331530633U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
